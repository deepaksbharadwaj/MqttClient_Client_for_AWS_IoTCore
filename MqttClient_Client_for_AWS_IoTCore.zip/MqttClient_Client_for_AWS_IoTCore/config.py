__author__ = "Deepak Sridhar Bharadwaj, started from code export from AWS"
__copyright__ = "Copyright (C) 2023 Continental Corporation - BA AN ESA (Ecosystem Architecture)"
__license__ = "All right reserved to Continental Corporation"
__version__ = "1.0"

ENDPOINT = "a1r8gg4naq8zjm-ats.iot.ap-northeast-2.amazonaws.com"  # Seoul AWS IoT Endpoint
CLIENT_ID = "ESA_SOA_TestDevice02"
PATH_TO_CERTIFICATE = "certificates/ESA_SOA_TestDevice02/ESA_SOA_TestDevice02.certificate.pem"
PATH_TO_PRIVATE_KEY = "certificates/ESA_SOA_TestDevice02/ESA_SOA_TestDevice02.privkey.pem"
PATH_TO_AMAZON_ROOT_CA_1 = "certificates/ESA_SOA_TestDevice02/AmazonRootCA1.pem"

MESSAGE = "Hello AWS, We are ESA Team"
TOPIC_PUB = "test/testing"

TOPIC_SUB = "driver/bodyVital/details"
RANGE = 3
SEC = 60