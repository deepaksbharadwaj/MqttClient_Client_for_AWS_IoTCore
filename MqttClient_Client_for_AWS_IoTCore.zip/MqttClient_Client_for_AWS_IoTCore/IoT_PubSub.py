__author__ = "Deepak Sridhar Bharadwaj, started from code export from AWS"
__copyright__ = "Copyright (C) 2023 Continental Corporation - BA AN ESA (Ecosystem Architecture)"
__license__ = "All right reserved to Continental Corporation"
__version__ = "1.0"

import config as cfg

from awscrt import io, mqtt
from awsiot import mqtt_connection_builder
import asyncio


# Spin up resources
event_loop_group = io.EventLoopGroup(1)
host_resolver = io.DefaultHostResolver(event_loop_group)
client_bootstrap = io.ClientBootstrap(event_loop_group, host_resolver)
mqtt_connection = mqtt_connection_builder.mtls_from_path(
    endpoint=cfg.ENDPOINT,
    cert_filepath=cfg.PATH_TO_CERTIFICATE,
    pri_key_filepath=cfg.PATH_TO_PRIVATE_KEY,
    client_bootstrap=client_bootstrap,
    ca_filepath=cfg.PATH_TO_AMAZON_ROOT_CA_1,
    client_id=cfg.CLIENT_ID,
    clean_session=False,
    keep_alive_secs=cfg.SEC
)


def on_message_received(topic, payload, **kwargs):
    # print("Received message from topic '{}': {}".format(topic, payload))
    topic_parsed = False
    if "/" in topic:
        parsed_topic = topic.split("/")
        if len(parsed_topic) == 3:
            # this topic has the format "topic/subtopic1/subtopic2"
            if (parsed_topic[0] == 'device') and (parsed_topic[2] == 'details'):
                if parsed_topic[1] == 'temp':
                    # device/temp/details: {"desiredTemp": 20, "currentTemp": 15}
                    print("Received temperature request: {}".format(payload))
                    topic_parsed = True
                if parsed_topic[1] == 'light':
                    # device/light/details: {"desiredLight": 100, "currentLight": 50}
                    print("Received light request: {}".format(payload))
                    topic_parsed = True
                if parsed_topic[1] == 'vehicle':
                    # device/vehicle/details: {"enginespeed":"90","tirepressure":"33","FuelType":"Petrol"}
                    print("Received vehicle info: {}".format(payload))
                    topic_parsed = True
            if (parsed_topic[0] == 'driver') and (parsed_topic[2] == 'details'):
                if parsed_topic[1] == 'bodyVital':
                    # driver/bodyVital/details: {"name":"Alex","heartrate":"122","SP-O2":"98","bodytempC":"36.5"}
                    print("Received Driver Body Vital Details: {}".format(payload))
                    topic_parsed = True
        if len(parsed_topic) == 2:
            # this topic has the format "topic/subtopic"
            print("Received Subscription request: {}".format(payload))
            topic_parsed = True
    if not topic_parsed:
        print("Unrecognized message topic.")


async def mqtt_Subscribe(topic, delay):
    loop = asyncio.get_running_loop()
    end_time = loop.time() + delay
    while True:
        # print("Blocking...", datetime.datetime.now())
        await asyncio.sleep(1)
        subscribe_future, packet_id = mqtt_connection.subscribe(
            topic=topic,
            qos=mqtt.QoS.AT_LEAST_ONCE,
            callback=on_message_received
        )
        subscribe_result = subscribe_future.result()
        # print(subscribe_result)
        if loop.time() > end_time:
            print("Done.")
            break

if __name__ == '__main__':
    print("This script can't run independently! Run IoT_Device_Ops.py")

# #############################################################################################
# # Init parameters : using AWS IoT SDK
# import time as t
# import AWSIoTPythonSDK.MQTTLib as AWSIoTPyMQTT
# import json
#
# myAWSIoTMQTTClient = AWSIoTPyMQTT.AWSIoTMQTTClient(cfg.CLIENT_ID)
# myAWSIoTMQTTClient.configureEndpoint(cfg.ENDPOINT, 8883)
# myAWSIoTMQTTClient.configureCredentials(cfg.PATH_TO_AMAZON_ROOT_CA_1, cfg.PATH_TO_PRIVATE_KEY, cfg.PATH_TO_CERTIFICATE)
#
# # connect
# myAWSIoTMQTTClient.connect()
#
# # publish
# print('Begin Publish')
# for i in range (cfg.RANGE):
#     data = "{} [{}]".format(cfg.MESSAGE, i+1)
#     message = {"message" : data}
#     myAWSIoTMQTTClient.publish(cfg.TOPIC_PUB, json.dumps(message), 1)
#     print("Published: '" + json.dumps(message) + "' to the topic: " + "'test/testing'")
#     t.sleep(0.1)
# print('Publish End')
#
# # disconnect
# myAWSIoTMQTTClient.disconnect()
# #############################################################################################