__author__ = "Deepak Sridhar Bharadwaj, started from code export from AWS"
__copyright__ = "Copyright (C) 2023 Continental Corporation - BA AN ESA (Ecosystem Architecture)"
__license__ = "All right reserved to Continental Corporation"
__version__ = "1.0"

from IoT_PubSub import *
import config as cfg

from awscrt import mqtt
import time as t
import json
import asyncio


# connect
print("Connecting to AWS IoT Core ENDPOINT {} with client ID '{}'...".format(cfg.ENDPOINT, cfg.CLIENT_ID))
connect_future = mqtt_connection.connect()
# Future.result() waits until a result is available
connect_future.result()
print("Connected!")

# Publish message to server desired number of times.
print('Begin Publish')
for i in range(cfg.RANGE):
    data = "{} [{}]".format(cfg.MESSAGE, i + 1)
    message = {"message": data}
    mqtt_connection.publish(topic=cfg.TOPIC_PUB, payload=json.dumps(message), qos=mqtt.QoS.AT_LEAST_ONCE)
    print("Published: '" + json.dumps(message) + "' to the topic: " + cfg.TOPIC_PUB)
    t.sleep(2)
print('Publish End')
t.sleep(0.5)

###################################################################################
# # Synchronous Subscribe to the desired topic from server
# subscribe_future, packet_id = mqtt_connection.subscribe(topic=TOPIC_SUB, qos=mqtt.QoS.AT_LEAST_ONCE,
#                                                         callback=on_message_received)
# subscribe_result = subscribe_future.result()
# print("Subscribed to topic '{}'...".format(str(subscribe_result['topic'])))
# print("Subscribed with {}".format(str(subscribe_result['qos'])))
###################################################################################

# Asynchronous Subscribe to the desired topic from server
asyncio.run(mqtt_Subscribe(cfg.TOPIC_SUB, cfg.SEC))

# disconnect
disconnect_future = mqtt_connection.disconnect()
disconnect_future.result()